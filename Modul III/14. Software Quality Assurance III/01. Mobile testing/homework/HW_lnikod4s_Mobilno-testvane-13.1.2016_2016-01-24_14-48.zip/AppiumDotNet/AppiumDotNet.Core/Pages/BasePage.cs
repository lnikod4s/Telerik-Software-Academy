﻿namespace AppiumDotNet.Core.Pages
{
    using OpenQA.Selenium.Appium;
    using OpenQA.Selenium.Appium.Android;

    public abstract class BasePage
    {
        protected BasePage(AppiumDriver<AndroidElement> driver)
        {
            this.Driver = driver;
        }

        public AppiumDriver<AndroidElement> Driver { get; set; }
    }
}