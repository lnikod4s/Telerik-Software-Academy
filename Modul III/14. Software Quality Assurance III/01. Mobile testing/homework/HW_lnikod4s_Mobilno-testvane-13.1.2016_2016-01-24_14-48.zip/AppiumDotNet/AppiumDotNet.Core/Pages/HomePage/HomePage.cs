﻿namespace AppiumDotNet.Core.Pages.HomePage
{
    using Constants;

    using OpenQA.Selenium.Appium;
    using OpenQA.Selenium.Appium.Android;

    public partial class HomePage : BasePage
    {
        public HomePage(AppiumDriver<AndroidElement> driver) : base(driver)
        {
        }

        public void SwitchOffNotifications()
        {
            this.VibrateSwitchElement.Click();
            this.SoundSwitchElement.Click();
        }

        public void EditHeightAndWeight(string height, string weight)
        {
            this.HeightEditTextElement.Clear();
            this.HeightEditTextElement.SendKeys(height);
            this.WeightEditTextElement.Clear();
            this.WeightEditTextElement.SendKeys(weight);
        }

        public void EditName(string name)
        {
            this.NameButtonElement.Click();
            this.PromptWindowEditTextElement.Clear();
            this.PromptWindowEditTextElement.SendKeys(HomePageConstants.Name);
            this.PromptWindowOkButtonElement.Click();
        }
    }
}