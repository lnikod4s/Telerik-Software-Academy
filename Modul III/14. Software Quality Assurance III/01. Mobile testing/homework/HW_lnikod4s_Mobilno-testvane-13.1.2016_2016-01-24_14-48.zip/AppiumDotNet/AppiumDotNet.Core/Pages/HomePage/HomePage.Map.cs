﻿namespace AppiumDotNet.Core.Pages.HomePage
{
    using System.Collections.ObjectModel;

    using OpenQA.Selenium.Appium.Android;

    public partial class HomePage
    {
        public AndroidElement FrameLayout => this.Driver.FindElementByClassName("android.widget.FrameLayout");

        public ReadOnlyCollection<AndroidElement> SwitchElements
            => this.Driver.FindElementsByClassName("android.widget.Switch");

        public AndroidElement VibrateSwitchElement => this.SwitchElements[0];

        public AndroidElement SoundSwitchElement => this.SwitchElements[1];

        public AndroidElement SeekBarElement => this.Driver.FindElementByClassName("android.widget.SeekBar");

        public ReadOnlyCollection<AndroidElement> EditTextElements
            => this.Driver.FindElementsByClassName("android.widget.EditText");

        public AndroidElement HeightEditTextElement => this.EditTextElements[0];

        public AndroidElement WeightEditTextElement => this.EditTextElements[1];

        public AndroidElement NameButtonElement => this.Driver.FindElementByClassName("android.widget.Button");

        public AndroidElement PromptWindowEditTextElement
            => this.Driver.FindElementByClassName("android.widget.EditText");

        public AndroidElement PromptWindowOkButtonElement
            => this.Driver.FindElementsByClassName("android.widget.Button")[1];
    }
}