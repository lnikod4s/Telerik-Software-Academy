﻿namespace AppiumDotNet.Core.Pages.HomePage
{
    using Constants;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    public partial class HomePage
    {
        public void VerifyHomePageLoaded()
        {
            Assert.IsTrue(this.FrameLayout.Displayed);
        }

        public void VerifyNotificationsSwitchedOff()
        {
            Assert.AreEqual(HomePageConstants.SliderOff, this.VibrateSwitchElement.Text);
            Assert.AreEqual(HomePageConstants.SliderOff, this.SoundSwitchElement.Text);
        }

        public void VerifySliderDisabled()
        {
            Assert.IsFalse(this.SeekBarElement.Enabled);
        }

        public void VerifyHeightUpdated()
        {
            Assert.AreEqual(HomePageConstants.Height, this.HeightEditTextElement.Text);
        }

        public void VerifyWeightUpdated()
        {
            Assert.AreEqual(HomePageConstants.Weight, this.WeightEditTextElement.Text);
        }

        public void VerifyNameUpdated()
        {
            Assert.AreEqual(HomePageConstants.Name, this.NameButtonElement.Text);
        }
    }
}