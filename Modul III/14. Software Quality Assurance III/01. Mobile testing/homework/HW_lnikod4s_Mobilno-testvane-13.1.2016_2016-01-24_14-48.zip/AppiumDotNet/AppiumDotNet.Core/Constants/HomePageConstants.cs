﻿namespace AppiumDotNet.Core.Constants
{
    public class HomePageConstants
    {
        public const string SliderOff = "OFF";
        public const string Height = "185";
        public const string Weight = "85";
        public const string Name = "Arnold Schwarzenegger";
    }
}