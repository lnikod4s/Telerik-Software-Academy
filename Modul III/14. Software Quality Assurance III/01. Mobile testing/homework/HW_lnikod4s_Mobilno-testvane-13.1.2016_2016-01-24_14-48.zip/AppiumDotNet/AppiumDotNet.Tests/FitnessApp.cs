﻿namespace AppiumDotNet.Tests
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    using Core.Constants;
    using Core.Pages.HomePage;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using OpenQA.Selenium.Appium;
    using OpenQA.Selenium.Appium.Android;
    using OpenQA.Selenium.Appium.Service;
    using OpenQA.Selenium.Appium.Service.Options;
    using OpenQA.Selenium.Remote;

    [TestClass]
    public class FitnessApp
    {
        [TestMethod]
        public void SwitchOffVibrateAndSound()
        {
            var homePage = new HomePage(driver);
            homePage.VerifyHomePageLoaded();
            homePage.SwitchOffNotifications();
            homePage.VerifyNotificationsSwitchedOff();
            homePage.VerifySliderDisabled();
        }

        [TestMethod]
        public void EditHeightAndWeight()
        {
            var homePage = new HomePage(driver);
            homePage.VerifyHomePageLoaded();
            homePage.EditHeightAndWeight(
                HomePageConstants.Height,
                HomePageConstants.Weight);
            homePage.VerifyHeightUpdated();
            homePage.VerifyWeightUpdated();

            homePage.Driver.BackgroundApp(10);
            homePage.VerifyHeightUpdated();
            homePage.VerifyWeightUpdated();
        }

        [TestMethod]
        public void EditName()
        {
            var homePage = new HomePage(driver);
            homePage.VerifyHomePageLoaded();
            homePage.EditName(HomePageConstants.Name);
            homePage.VerifyNameUpdated();

            homePage.Driver.BackgroundApp(10);
            homePage.VerifyNameUpdated();
        }

        #region Setup Appium Server [Real Magic Happens Here]

        private static AppiumLocalService service;
        private static AppiumDriver<AndroidElement> driver;

        [ClassInitialize]
        public static void CoreClassInitialize(TestContext testContext)
        {
            /* .:: NOTES ::.
            * Please replace device names in lines 72 & 88 with your own android device name
            * Ensure that you have downloaded fitness-debug.apk in C:\TMP\ or change the path (s. line 90)
            */
            // Start Appium Server
            var avdOptions = new KeyValuePair<string, string>("--avd", "Api19-Default");
            var args = new OptionCollector();
            args.AddArguments(avdOptions);

            var appiumJsPath = Environment.ExpandEnvironmentVariables("%AppData%") + @"\npm\node_modules\appium\bin\appium.js";
            service = new AppiumServiceBuilder()
                .WithAppiumJS(new FileInfo(appiumJsPath))
                .UsingDriverExecutable(new FileInfo(@"C:\Program Files (x86)\Appium\node.exe"))
                .WithArguments(args)
                .UsingAnyFreePort()
                .Build();
            service.Start();
            Assert.IsTrue(service.IsRunning);

            // Start Appium Client
            var capabilities = new DesiredCapabilities();
            capabilities.SetCapability("deviceName", "Api19-Default");
            capabilities.SetCapability("platformName", "Android");
            capabilities.SetCapability("app", "C:\\TMP\\fitness-debug.apk");
            driver = new AndroidDriver<AndroidElement>(service.ServiceUrl, capabilities, TimeSpan.FromSeconds(180));
        }

        [ClassCleanup]
        public static void CoreClassCleanup()
        {
            driver.Quit();
            service.Dispose();
        }

        #endregion
    }
}