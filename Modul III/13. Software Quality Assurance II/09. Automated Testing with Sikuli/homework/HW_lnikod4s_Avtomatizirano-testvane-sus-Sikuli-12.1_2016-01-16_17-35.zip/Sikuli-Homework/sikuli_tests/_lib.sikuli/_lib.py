from sikuli import *
import HTMLTestRunner
bdLibPath = os.path.abspath(sys.argv[0] + "..")
if not bdLibPath in sys.path: sys.path.append(bdLibPath)
from _uimap import *

def RunBrowserToUrl(browser, url):
    sleep(0.5)
    type("d", KEY_WIN); sleep(1)   
    type("r", KEY_WIN); sleep(1)
    type(browser + " " + url); sleep(1)
    type(Key.ENTER)

def RunDesktopApp(program):
    sleep(0.5)
    type("d", KEY_WIN); sleep(1)   
    type("r", KEY_WIN); sleep(1)
    type(program); sleep(1)
    type(Key.ENTER)

def MinimizeAllWindows():
    sleep(0.5)
    type("d", KEY_WIN)
    sleep(2)
    type("d", KEY_WIN)
    sleep(2)