########################################################
# UI map for Sikuli Homework
########################################################
from sikuli import *
########################################################

class GoogleSearchTelerikAcademy:
    box_SearchBox = "box_SearchBox.png"
    label_TelerikAcademy = "label_TelerikAcademy.png"

class HTMLGoodiesDragAndDrop:
    label_DragAndDrop = "label_DragAndDrop.png"
    box_Copenhagen = "box_Copenhagen.png"
    box_CountriesCapitals = "box_CountriesCapitals.png"
    box_Denmark = "box_Denmark.png"
    box_Italy = "box_Italy.png"
    box_Madrid = "box_Madrid.png"
    box_Norway = "box_Norway.png"
    box_Oslo = "box_Oslo.png"
    box_Rome = "box_Rome.png"
    box_Seoul = "box_Seoul.png"
    box_SouthKorea = "box_SouthKorea.png"
    box_Spain = "box_Spain.png"
    box_Stockholm = "box_Stockholm.png"
    box_Sweden = "box_Sweden.png"
    box_UnitedStates = "box_UnitedStates.png"
    box_Washington = "box_Washington.png"

class SkypeMessageToFriend:
    box_SkypeSearch = "box_SkypeSearch.png"
    box_TypeField = "box_TypeField.png"

class CalcOperations:
    label_Standard = "label_Standard.png"
    label_CannotDivideByZero = "label_CannotDivideByZero.png"

class ContextMenu:
    box_SearchBox = "box_SearchBox.png"
    image_NinjaChampion = "image_NinjaChampion.png"
    label_Images = "label_Images.png"