import unittest
bdLibPath=os.path.abspath(sys.argv[0]+"..")
if not bdLibPath in sys.path: sys.path.append(bdLibPath)
from _lib import *

    
class SmokeTests(unittest.TestCase):
    
    def setUp(self):
        pass
    
    def tearDown(self):
        pass    
    
    ##########################################################################################
    ######################################### Task 1 #########################################  
    ##########################################################################################
    def test_001_NavigateTo(self):
        RunBrowserToUrl("firefox", "http://www.google.com/")
        wait(GoogleSearchTelerikAcademy.box_SearchBox, 10).highlight(2)
    
    def test_002_SearchTelerikAcademy(self):
        wait(GoogleSearchTelerikAcademy.box_SearchBox, 10).highlight(2)
        click(GoogleSearchTelerikAcademy.box_SearchBox)
        type("Telerik Academy")
        type(Key.ENTER)
        wait(GoogleSearchTelerikAcademy.label_TelerikAcademy, 10).highlight(2)
        type(Key.F4, KeyModifier.ALT)

    ##########################################################################################
    ######################################### Task 2 #########################################  
    ##########################################################################################

    def test_003_NavigateTo(self):
        RunBrowserToUrl("firefox", "http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html")

    def test_004_DragAndDropCapitalsToCountries(self):
        wait(HTMLGoodiesDragAndDrop.label_DragAndDrop, 10).highlight(2)
        dragDrop(HTMLGoodiesDragAndDrop.box_Oslo, HTMLGoodiesDragAndDrop.box_Norway); sleep(1)
        dragDrop(HTMLGoodiesDragAndDrop.box_Stockholm, HTMLGoodiesDragAndDrop.box_Sweden); sleep(1)
        dragDrop(HTMLGoodiesDragAndDrop.box_Washington, HTMLGoodiesDragAndDrop.box_UnitedStates); sleep(1)
        dragDrop(HTMLGoodiesDragAndDrop.box_Copenhagen, HTMLGoodiesDragAndDrop.box_Denmark); sleep(1)
        dragDrop(HTMLGoodiesDragAndDrop.box_Seoul, HTMLGoodiesDragAndDrop.box_SouthKorea); sleep(1)
        dragDrop(HTMLGoodiesDragAndDrop.box_Rome, HTMLGoodiesDragAndDrop.box_Italy); sleep(1)
        dragDrop(HTMLGoodiesDragAndDrop.box_Madrid, HTMLGoodiesDragAndDrop.box_Spain)
        wait(HTMLGoodiesDragAndDrop.box_CountriesCapitals, 10).highlight(2)
        type(Key.F4, KeyModifier.ALT)

    ##########################################################################################
    ######################################### Task 3 #########################################  
    ##########################################################################################

    def test_005_MinimizeAllActiveWindows(self):
        MinimizeAllWindows()

    ##########################################################################################
    ######################################### Task 4 #########################################  
    ##########################################################################################

    def test_006_RunDesktopApp(self):
        RunDesktopApp("skype")

    def test_007_SendMessageToSkypeFriend(self):
        wait(SkypeMessageToFriend.box_SkypeSearch, 10).highlight(2)
        click(SkypeMessageToFriend.box_SkypeSearch)
        # Please enter your friend's name
        friendName = "nencho natasha"
        type(friendName); sleep(1)
        type(Key.ENTER)
        wait(SkypeMessageToFriend.box_TypeField, 10).highlight(2)
        click(SkypeMessageToFriend.box_TypeField); sleep(2)
        type("test")
        type(Key.ENTER)

    ##########################################################################################
    ######################################### Task 5 #########################################  
    ##########################################################################################

    def test_008_RunDesktopApp(self):
        RunDesktopApp("calc")

    def test_009_CheckStandardCalcOperations(self):
        wait(CalcOperations.label_Standard, 10).highlight(2)
        type("1"); sleep(1)
        type("+"); sleep(1)
        type("1"); sleep(1)
        type(Key.ENTER); sleep(2)
        type(Key.DELETE); sleep(1)
        type("1"); sleep(1)
        type("-"); sleep(1)
        type("1"); sleep(1)
        type(Key.ENTER); sleep(2)
        type(Key.DELETE); sleep(1)
        type("1"); sleep(1)
        type("*"); sleep(1)
        type("1"); sleep(1)
        type(Key.ENTER); sleep(2)
        type(Key.DELETE); sleep(1)
        type("1"); sleep(1)
        type("/"); sleep(1)
        type("1"); sleep(1)
        type(Key.ENTER); sleep(2)

    def test_010_CheckDivisionByZero(self):
        type(Key.DELETE); sleep(1)
        type("1"); sleep(1)
        type("/"); sleep(1)
        type("0"); sleep(1)
        type(Key.ENTER); sleep(2)
        wait(CalcOperations.label_CannotDivideByZero, 10).highlight(2)
        type(Key.F4, KeyModifier.ALT)

    ##########################################################################################
    ######################################### Task 6 #########################################  
    ##########################################################################################

    def test_011_NavigateTo(self):
        RunBrowserToUrl("firefox", "http://www.google.bg/")

    def test_012_FindTelerikAcademyImage(self):
        wait(ContextMenu.box_SearchBox, 10).highlight(2)
        click(ContextMenu.box_SearchBox)
        type("Telerik Academy")
        type(Key.ENTER)
        wait(ContextMenu.label_Images, 10).highlight(2)
        click(ContextMenu.label_Images); sleep(1)
        wait(ContextMenu.image_NinjaChampion, 10).highlight(2)
        rightClick(ContextMenu.image_NinjaChampion); sleep(1)
        type("t"); sleep(1)
        type(Key.TAB, KeyModifier.CTRL); sleep(1)
        type(Key.F4, KeyModifier.ALT)

if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(SmokeTests)

    outfile = open("report.html", "w")
    runner = HTMLTestRunner.HTMLTestRunner(stream=outfile, title='SmokeTests Report')
    runner.run(suite)
    outfile.close()