﻿// TODO: Describe patterns, SOLID, bugs and bottleneck in Documentation.txt
public static class БръмБръм
{
    public static void Main(int a)
    {var webSever = new WebServerConsole5();webSever.Start()}
};
