﻿public interface IActionResult
{
    HttpResponse GetResponse();
}